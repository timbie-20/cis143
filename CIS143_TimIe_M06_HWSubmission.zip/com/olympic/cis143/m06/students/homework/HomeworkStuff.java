package com.olympic.cis143.m06.students.homework;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;


/**
 * This lab uses the java Stream API.
 */
public class HomeworkStuff {

    /**
     * This method will:
     * 1. sort the names
     * 2. convert the names to uppercase.
     * @param names The list of unsorted names in lowercase.
     * @return The sorted list in uppercase.
     */
    public List<String> orderNamesAndConvertToUppercase(final List<String> names) {
        List<String> newList = new ArrayList<String>();
    	names.stream().map(name -> name.toUpperCase()).sorted().forEach(name -> newList.add(name));
        System.out.println(newList);
        return newList;
    }

    /**
     * This adds all the integers in a list together.
     * @param integrers A list of integers
     * @return The total.
     */
    public Integer calculateAddListValues(final List<Integer> integrers) {
    	Integer sum = integrers.stream().reduce(0, (v1,v2) -> v1+v2);
    	return sum;
    }

    /**
     * From the list, filter and find the oldest person.
     *
     * @param people A list of people.
     * @return The oldest person.
     */
    public Optional<Person> findTheOldestPerson(final List<Person> people) {
        // Stream<Person> sortedStream = people.stream().sorted((p1,p2) -> p1.getAge().compareTo(p2.getAge()));
        return people.stream().max(Comparator.comparing(Person::getAge));
    }
    

    /**
     * Filters out anyone under 21.
     * @param people A list of people.
     * @return Only people 21 or over.
     */
    public List<Person> findPeople21OrOver(final List<Person> people) {
        List<Person> list21OverPeople = new ArrayList<Person>();
    	people.stream().filter(person -> person.getAge() >= 21).forEach(person -> list21OverPeople.add(person));
    	return list21OverPeople;
    }

    /**
     * Orders the people by age.
     * @param people A list of people to order by age.
     * @return The ordered list of people by age.
     */
    public List<Person> orderByAge(final List<Person> people){
        List<Person> agedOrdered = new ArrayList<Person>();
        people.stream().sorted((p1, p2) -> p1.getAge().compareTo(p2.getAge())).forEach(person -> agedOrdered.add(person));
        return agedOrdered;
    }
}
