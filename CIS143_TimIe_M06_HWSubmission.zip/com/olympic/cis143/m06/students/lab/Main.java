package com.olympic.cis143.m06.student.lab;

public class Main {
	
	/*var foo = 1;

	function bar() {
		print(foo);
		
	}

	print(foo);

	function bar() {
		var foo = 1;
		print(foo);
		
	}
	
	print(foo);
	bar();*/
	
	// A closure is a bucket of references to variables a function needs to execute which are declared outside its scope.
	
	/*function foo() {
		var a = 10;//outer scope
		
		return function bar() {
			var b = 10; //inner scope
			print(a + b);
		}
	}
	
	foo(); // prints 20
	
	function foo(param) {
		return function bar() {
			var b = 10;//inner scope
			print(param + b);
		}
	}
	
	var anotherWayToCall = foo(10); //this returns a function
	anotherWayToCall(); //prints 20*/
	
	
	
}