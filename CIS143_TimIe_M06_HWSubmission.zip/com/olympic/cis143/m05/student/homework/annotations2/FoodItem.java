package com.olympic.cis143.m05.student.homework.annotations2;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(TYPE)
public @interface FoodItem {

	@SuppressWarnings("rawtypes")
	Class type();
}
