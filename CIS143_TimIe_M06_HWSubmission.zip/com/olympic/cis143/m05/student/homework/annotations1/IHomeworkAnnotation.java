package com.olympic.cis143.m05.student.homework.annotations1;

public interface IHomeworkAnnotation {

    String sayHello();
}
