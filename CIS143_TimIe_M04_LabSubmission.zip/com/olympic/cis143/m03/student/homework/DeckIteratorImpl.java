package com.olympic.cis143.m03.student.homework;

import java.util.List;
import com.olympic.cis143.m03.student.homework.Card;
import java.util.ArrayList;
import java.util.Collections;

public class DeckIteratorImpl implements Deck {

	private ArrayList<Card> deck;
	
	public DeckIteratorImpl(boolean jokers) {
		deck = new ArrayList<Card>();
		this.createDeck(jokers);
	}
	
	private void createDeck(final boolean jokers) {
    	for (Card.Suit suit : Card.Suit.values()) {
    		if (suit == Card.Suit.NONE) { // if iterating through Joker suit
    			if (jokers) {
	        		deck.add(new Card(Card.Suit.NONE, Card.Value.JOKER));
	        		deck.add(new Card(Card.Suit.NONE, Card.Value.JOKER));
    			}
    		} else {
	    		for (Card.Value cardVal : Card.Value.values()) {
	    			if (cardVal != Card.Value.JOKER) {		// for all other suits & values
	    				// System.out.println(suit.toString() + ", " + cardVal.toString());
	    				deck.add(new Card(suit, cardVal));
	    			}
	    		}
    		}
    	}
    	
    }
	
	@Override
	public List<Card> getDeck() {
		return this.deck;
	}

	@Override
	public void shuffle() {
		Collections.shuffle(this.deck);
	}

	@Override
	public boolean hasNext() {
		return !this.deck.isEmpty();
	}

	@Override
	public Card dealCard() {
		Card dealtCard;
		
		if (this.deck.isEmpty()) {
			throw new RuntimeException("Deck is empty; cannot deal new card.");
		} else {
			dealtCard = this.deck.remove(0);
		}
		return dealtCard;
	}

}
