package com.olympic.cis143.m04.student.homework.tacotruckmap.impl;

import com.olympic.cis143.m04.student.homework.tacotruckmap.OrderDoesNotExistException;
import com.olympic.cis143.m04.student.homework.tacotruckmap.Orders;
import com.olympic.cis143.m04.student.homework.tacotruckmap.TacoImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrdersMapImpl implements Orders {

	private HashMap<String,ArrayList<TacoImpl>> ordersMap = new HashMap<String,ArrayList<TacoImpl>>(15);
	
    @Override
    public void createOrder(final String orderid) {
    	ArrayList<TacoImpl> thisOrderTacoList = new ArrayList<TacoImpl>();
    	ordersMap.put(orderid, thisOrderTacoList);
    }

    @Override
    public void addTacoToOrder(final String orderid, final TacoImpl taco) throws OrderDoesNotExistException {
    	ArrayList<TacoImpl> addToList = ordersMap.get(orderid);
    	addToList.add(taco);
    }

    @Override
    public boolean hasNext() {
        return !ordersMap.isEmpty();
    }

    @Override
    public List<TacoImpl> closeOrder(final String orderid) throws OrderDoesNotExistException {
        return ordersMap.remove(orderid);
    }

    @Override
    public int howManyOrders() {
        return ordersMap.size();
    }

    @Override
    public List<TacoImpl> getListOfOrders(final String orderid) throws OrderDoesNotExistException {
        return ordersMap.get(orderid);
    }
}
