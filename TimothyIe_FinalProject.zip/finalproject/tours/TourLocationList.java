package com.olympic.cis143.finalproject.tours;

public class TourLocationList {

}
