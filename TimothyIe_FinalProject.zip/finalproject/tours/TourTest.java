package com.olympic.cis143.finalproject.tours;

import java.time.LocalDateTime;

import com.olympic.cis143.finalproject.tours.Tour.TourList;
import com.olympic.cis143.finalproject.tours.reserve.Payment;
import com.olympic.cis143.finalproject.tours.reserve.Reservation;
import com.olympic.cis143.finalproject.tours.reserve.Payment.PaymentMethod;
import com.olympic.cis143.finalproject.tours.review.TourReview;
import com.olympic.cis143.finalproject.tours.review.TourReview.StarRating;

public class TourTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TourLocation locationSanJuan = new TourLocation(001, "San Juan Islands", "See amazing orcas and other marine life in the majestic San Juan Islands off the west coast of Washington, teeming with all kinds of nature.");
		TourLocation locationPtRobinson = new TourLocation(002, "Point Robinson", "By this narrow strip of land, come see the sandy beaches as the orcas, seals, and otters swim right by your boat. You're bound to capture the perfect view on this tour!");
		Tour tour101 = new Tour(101, 15.4, locationSanJuan, 70, 1314);
		if (TourList.theTourList.size() != 1) {
			throw new RuntimeException("ERROR: One tour should currently be in the master tour list.");
		} else {
			System.out.println("Tour successfully created!");
		}
		Reservation res1 = new Reservation(0001, tour101, "Sables", "Sandy", new int[] {2, 2, 1, 0}, "Need wheelchair space.", new Payment(PaymentMethod.PAYPAL, "1234567891234567"));
		System.out.println(res1.calculateCost());
		if (res1.getTotalTickets() != 5) {
			throw new RuntimeException("ERROR: Should be 5 here.");
		} else {
			System.out.println("Test passed!");
		}
		Reservation res2 = new Reservation(0002, tour101, "Rick", "Jon", new int[] {0, 2, 0, 1}, new Payment(PaymentMethod.PAYPAL, "1234567891234569"));
		if (tour101.currentReservedSeats != 8) {
			throw new RuntimeException("Error: Should be 8 seats reserved.");
		} else {
			System.out.println("Successfully passed!");
		}
		TourReview review1 = new TourReview(tour101, StarRating.FOUR_STARS, StarRating.THREE_STARS, StarRating.FIVE_STARS, StarRating.FOUR_STARS, 
				"This was a decent tour. The staff were super helpful and friendly, and there was plenty to do and buy on the ship (including a small gift shop on the ferry!)"
				+ " but the tour itself was kind of hard to see. Unfortunately we had some bad luck as it was a pretty foggy day, but what little we could see of " 
				+ "of the local nature and the whales, it was great. I'd like to come back on a day where we have a better shot of viewing the wildlife.");
		System.out.println(review1.getTour() + ", " + review1.getOverallRating() + ". REVIEW TEXT: " + review1.getReviewText());
	}

}