package com.olympic.cis143.finalproject.tours;

import java.util.ArrayList;

import com.olympic.cis143.finalproject.tours.TourLocation.StarRatingHalves;

public class TourLocation {
	
	public TourLocation(int locationID, String location, String description) {
		super();
		this.locationID = locationID;
		this.location = location;
		this.description = description;
	}

	static ArrayList<TourLocation> theLocationList = new ArrayList<TourLocation>();
	
	public enum StarRatingHalves {
		NOT_AVAILABLE, ONE_STAR, ONE_N_HALF_STARS, TWO_STARS, TWO_N_HALF_STARS,
		THREE_STARS, THREE_N_HALF_STARS, FOUR_STARS, FOUR_N_HALF_STARS, FIVE_STARS
	};
	int locationID;
	String location;
	String description;
	StarRatingHalves popularity;
	double popularityAmount;
	int numReviews = 0;
	double totalRating;
	
	
	public int getLocationID() {
		return locationID;
	}
	public void setLocationID(int locationID) {
		for (TourLocation tourLocation : theLocationList) {
			if (tourLocation.locationID == locationID) {
				throw new RuntimeException("Chosen location ID already exists; please input another location ID.");
			}
		}
		this.locationID = locationID;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String descriptionEntered) {
		if (descriptionEntered.length() <= 500) this.description = descriptionEntered; // places a limit on descriptions that can be entered
	}
	public StarRatingHalves getPopularity() {
		return popularity;
	}
	
	public void setPopularityAmount(double popularityAmount) {
		this.popularityAmount = popularityAmount;
	}
	
	
	@Override
	public boolean equals(Object other) {
		TourLocation otherAsTourLoc = (TourLocation) other;
		if (this.locationID == otherAsTourLoc.locationID) {
			return true;
		}
		return false;
	}
	private void updatePopularityRating() {
		if (popularityAmount < 1.25) {
			popularity = StarRatingHalves.ONE_STAR;
		} else if (popularityAmount < 1.75) {
			popularity = StarRatingHalves.ONE_N_HALF_STARS;
		} else if (popularityAmount < 2.25) {
			popularity = StarRatingHalves.TWO_STARS;
		} else if (popularityAmount < 2.75) {
			popularity = StarRatingHalves.TWO_N_HALF_STARS;
		} else if (popularityAmount < 3.25) {
			popularity = StarRatingHalves.THREE_STARS;
		} else if (popularityAmount < 3.75) {
			popularity = StarRatingHalves.THREE_N_HALF_STARS;
		} else if (popularityAmount < 4.25) {
			popularity = StarRatingHalves.FOUR_STARS;
		} else if (popularityAmount < 4.75) {
			popularity = StarRatingHalves.FOUR_N_HALF_STARS;
		} else {
			popularity = StarRatingHalves.FIVE_STARS;
		}
	}
	
}
