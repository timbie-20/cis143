package com.olympic.cis143.finalproject.tours.review;

import com.olympic.cis143.finalproject.tours.Tour;
import com.olympic.cis143.finalproject.tours.review.TourReview.StarRating;

public class TourReview {

	public enum StarRating {
		ONE_STAR, TWO_STARS, THREE_STARS, FOUR_STARS, FIVE_STARS;
	}
	
	Tour tour; // tour for which the given review is for
	StarRating overallRating;
	StarRating serviceRating;
	StarRating sightsRating;
	StarRating amenitiesRating;
	String reviewText;
	
	public TourReview(Tour tour, StarRating overallRating, StarRating serviceRating, StarRating sightsRating,
			StarRating amenitiesRating, String reviewText) {
		super();
		this.tour = tour;
		this.overallRating = overallRating;
		this.serviceRating = serviceRating;
		this.sightsRating = sightsRating;
		this.amenitiesRating = amenitiesRating;
		this.reviewText = reviewText;
	}
	
	
	public StarRating getOverallRating() {
		return overallRating;
	}
	public void setOverallRating(StarRating overallRating) {
		this.overallRating = overallRating;
	}
	public StarRating getServiceRating() {
		return serviceRating;
	}
	public void setServiceRating(StarRating serviceRating) {
		this.serviceRating = serviceRating;
	}
	public StarRating getSightsRating() {
		return sightsRating;
	}
	public void setSightsRating(StarRating sightsRating) {
		this.sightsRating = sightsRating;
	}
	public StarRating getAmenitiesRating() {
		return amenitiesRating;
	}
	public void setAmenitiesRating(StarRating amenitiesRating) {
		this.amenitiesRating = amenitiesRating;
	}
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		if (reviewText.length() > 1000) {
			throw new RuntimeException("Review character limit exceeded; reviews are limited to 1000 characters."); // character limit 1000 characters
		}
		this.reviewText = reviewText;
	}
	public Tour getTour() {
		return tour;
	}

	
}
