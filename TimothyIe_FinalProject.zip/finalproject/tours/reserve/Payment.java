package com.olympic.cis143.finalproject.tours.reserve;

import com.olympic.cis143.finalproject.tours.reserve.Payment.PaymentMethod;

public class Payment {
	
	public enum PaymentMethod {
		CREDITCARD, PAYPAL;
	}
	
	
	public Payment(PaymentMethod method, String ccNumber) {
		super();
		this.method = method;
		this.ccNumber = ccNumber;
	}
	PaymentMethod method;
	public PaymentMethod getMethod() {
		return method;
	}
	public void setMethod(PaymentMethod method) {
		this.method = method;
	}
	public String getCcNumber() {
		return ccNumber;
	}
	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}
	String ccNumber; // credit card number as 16-digit string
	
}
