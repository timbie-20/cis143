package com.olympic.cis143.finalproject.tours.reserve;

import com.olympic.cis143.finalproject.tours.Tour;

public class Reservation {
	
	final double CHILD_COST = 21.00;
	final double SENIOR_COST = 25.00;
	final double ADULT_COST = 33.00;
	final double STUDENT_COST = 25.00;
	
	int reservID;
	Tour forTour;
	String lastName;
	String firstName;
	int[] tickets = new int[4]; // [adult, child, senior, student]
	String commentsReqts; // additional comments about reservation
	Payment payment;
	
	public Reservation(int reservID, Tour forTour, String lastName, String firstName, int[] tickets,
			String commentsReqts, Payment payment) {
		super();
		this.reservID = reservID;
		this.forTour = forTour;
		this.lastName = lastName;
		this.firstName = firstName;
		if (tickets.length != 4) {
			throw new RuntimeException("Invalid ticket-number array; must be of length 4 for four different ticket types");
		}
		this.tickets = tickets;
		this.commentsReqts = commentsReqts;
		this.payment = payment;
		forTour.removeOpenSeats(tickets[0] + tickets[1] + tickets[2] + tickets[3]);
	}

	
	public Reservation(int reservID, Tour forTour, String lastName, String firstName, int[] tickets, Payment payment) {
		super();
		this.reservID = reservID;
		this.forTour = forTour;
		this.lastName = lastName;
		this.firstName = firstName;
		if (tickets.length != 4) {
			throw new RuntimeException("Invalid ticket-number array; must be of length 4 for four different ticket types");
		}
		this.tickets = tickets;
		this.payment = payment;
		forTour.removeOpenSeats(tickets[0] + tickets[1] + tickets[2] + tickets[3]);
	}


	public Tour getForTour() {
		return forTour;
	}

	public void setForTour(Tour forTour) {
		this.forTour = forTour;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int[] getTickets() {
		return tickets;
	}

	public void setTickets(int[] tickets) {
		this.tickets = tickets;
	}

	public String getCommentsReqts() {
		return commentsReqts;
	}

	public void setCommentsReqts(String commentsReqts) {
		this.commentsReqts = commentsReqts;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public int getReservID() {
		return reservID;
	}
	
	public int getTotalTickets() {
		return (tickets[0] + tickets[1] + tickets[2] + tickets[3]);
	}
	
	public double calculateCost() {
		return ((tickets[0] * ADULT_COST) + (tickets[1] * CHILD_COST) + (tickets[2] * SENIOR_COST) + (tickets[3] * STUDENT_COST) );
	}
	
	
}
