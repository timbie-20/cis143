package com.olympic.cis143.finalproject.tours;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Tour {
	
	public static class TourList {
			
		static ArrayList<Tour> theTourList = new ArrayList<Tour>();
		
		public void removeID(int tourID) {
			for(Tour tour : theTourList) {
				if (tour.tourID == tourID)
					theTourList.remove(tour);
				}
			}
			
		public ArrayList<Tour> getTripsByLocation(TourLocation myLocation) {
			ArrayList<Tour> sublist = new ArrayList<Tour>();
			for (Tour tour : theTourList) {
				if (tour.tourLocation.equals(myLocation)) {
					sublist.add(tour);
				}
			}
			return sublist;
		}
		
		public ArrayList<Tour> getShorterTrips(double lengthCriteria) {
			ArrayList<Tour> sublist = new ArrayList<Tour>();
			for (Tour tour : theTourList) {
				if (tour.distanceMiles < lengthCriteria) {
					sublist.add(tour);
				}
			}
			return sublist;
		}
	}

	public Tour(int tourID, double distanceMiles, int maxCapacity, TourLocation tourLocation, LocalDateTime startTime,
			LocalDateTime endTime, int shipNumber, ArrayList<String> amenities) {
		this.tourID = tourID;
		this.distanceMiles = distanceMiles;
		this.maxCapacity = maxCapacity;
		this.tourLocation = tourLocation;
		this.startTime = startTime;
		this.endTime = endTime;
		this.shipNumber = shipNumber;
		this.amenities = amenities;
		TourList.theTourList.add(this);
	}
	
	public Tour(int tourID, int maxCapacity) {
		this.tourID = tourID;
		this.maxCapacity = maxCapacity;
		TourList.theTourList.add(this);
	}

	public Tour(int tourID, double distanceMiles, TourLocation tourLocation, int maxCapacity, int shipNumber) {
		super();
		this.tourID = tourID;
		this.distanceMiles = distanceMiles;
		this.tourLocation = tourLocation;
		this.maxCapacity = maxCapacity;
		this.shipNumber = shipNumber;
		TourList.theTourList.add(this);
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return (this.tourID + ", " + this.tourLocation.location);
	}


	int tourID;
	double distanceMiles;
	int maxCapacity;
	int currentReservedSeats = 0;
	TourLocation tourLocation;
	LocalDateTime startTime;
	LocalDateTime endTime;
	int shipNumber;
	ArrayList<String> amenities;
	

	public double getDistanceMiles() {
		return distanceMiles;
	}

	public void setDistanceMiles(double distanceMiles) {
		this.distanceMiles = distanceMiles;
	}

	public int getMaxCapacity() {
		return maxCapacity;
	}

	public void setMaxCapacity(int maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	public TourLocation getTourLocation() {
		return tourLocation;
	}

	public void setTourLocation(TourLocation tourLocation) {
		this.tourLocation = tourLocation;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public int getShipNumber() {
		return shipNumber;
	}

	public void setShipNumber(int shipNumber) {
		this.shipNumber = shipNumber;
	}

	public ArrayList<String> getAmenities() {
		return amenities;
	}

	public void setAmenities(ArrayList<String> amenities) {
		this.amenities = amenities;
	}

	public int getTourID() {
		return tourID;
	}

	public int getCurrentReservedSeats() {
		return currentReservedSeats;
	}
	
	public void addOpenSeats(int seatsToAdd) {
		if (seatsToAdd > currentReservedSeats) { // if vacating open seats would result in a negative number of reservations
			throw new RuntimeException("Seats to open is larger than number of currently reserved seats.\n Operation would result in more open seats than the maximum capacity.");
		} else {
			currentReservedSeats -= seatsToAdd;
		}
	}
	
	public void removeOpenSeats(int seatsToRemove) {
		if (seatsToRemove + currentReservedSeats > maxCapacity) { // if the reservation would cause the total to exceed the maximum capacity
			throw new RuntimeException("Not enough seats available on this tour to complete this reservation.");
		} else {
			currentReservedSeats += seatsToRemove;
		}
	}
	
}
