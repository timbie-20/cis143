package com.olympic.cis143.m03.student.tacotruck.list;

import java.util.ArrayList;
import com.olympic.cis143.m03.student.tacotruck.Orders;
import com.olympic.cis143.m03.student.tacotruck.TacoImpl;

public class OrdersListImpl implements Orders {

	private ArrayList<TacoImpl> orderList = new ArrayList<TacoImpl>();
	
	@Override
	public void addOrder(TacoImpl tacoOrder) {
		this.orderList.add(tacoOrder);
	}

	@Override
	public boolean hasNext() {
		return !this.orderList.isEmpty();
	}

	@Override
	public TacoImpl closeNextOrder() {
		return this.orderList.remove(0);
	}

	@Override
	public int howManyOrders() {
		return this.orderList.size();
	}

}
