package com.olympic.cis143.m05.student.homework.annotations2;

@FoodItem(type = Taco.class)
public class Taco {

}
