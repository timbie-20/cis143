package com.olympic.cis143.m05.student.lab.trycatch;

public class MyException extends Exception {
	
	public MyException(String message) throws Exception {
		throw new Exception(message);
	}

	public MyException() throws Exception {
		throw new Exception();
	}
}
