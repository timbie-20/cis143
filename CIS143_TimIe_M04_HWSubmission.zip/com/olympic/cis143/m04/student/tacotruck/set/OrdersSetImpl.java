package com.olympic.cis143.m04.student.tacotruck.set;

import java.util.ArrayList;
import com.olympic.cis143.m04.student.tacotruck.Orders;
import com.olympic.cis143.m04.student.tacotruck.TacoImpl;

public class OrdersSetImpl  implements Orders {
    
	private ArrayList<TacoImpl> orderList = new ArrayList<TacoImpl>();
	
	@Override
    public void addOrder(TacoImpl tacoOrder) {
    	orderList.add(tacoOrder);
    }

    @Override
    public boolean hasNext() {
        return !orderList.isEmpty();
    }

    @Override
    public TacoImpl closeNextOrder() {
       return orderList.remove(0);
    }

    @Override
    public int howManyOrders() {
        return orderList.size();
    }
}
